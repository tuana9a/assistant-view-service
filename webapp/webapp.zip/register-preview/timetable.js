
var TABLE_ROW_HEIGHT = 23;
// var TABLE_ROW_HEIGHT = 24;
// var TABLE_ROW_HEIGHT = 25;
var TABLE_ROW_HEIGHT_PX = TABLE_ROW_HEIGHT + "px";

var previewClasses = [];                                     //EXPLAIN: mảng lữu dữ liệu class hiện tại
var dayweekElements = [[], [], [], [], [], [], []];          //EXPLAIN: mảng lưu các div thứ trong tuần
var previewClassesDayWeek = [[], [], [], [], [], [], []];      //EXPLAIN: tiện cho render, check trùng thời gian

var renderTableTag = document.getElementById("renderTable");
var messageQueueTag = document.getElementById("messageQueue");


function initTable() {

    function createFirstColumn() {
        let column = document.createElement("div");
        column.classList.add("column", "positionRelative", "indexHour")
        column.innerHTML = `
            <div class="columName" style="height:${TABLE_ROW_HEIGHT_PX}"><span></span></div>
            <div class="hourOfDay dadFlexCenter _0h notWorkTime startDayHour" style="height:${TABLE_ROW_HEIGHT_PX}">0</div>
            <div class="hourOfDay dadFlexCenter _1h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"><span>1</span></div>
            <div class="hourOfDay dadFlexCenter _2h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"><span>2</span></div>
            <div class="hourOfDay dadFlexCenter _3h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"><span>3</span></div>
            <div class="hourOfDay dadFlexCenter _4h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"><span>4</span></div>
            <div class="hourOfDay dadFlexCenter _5h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"><span>5</span></div>
            <div class="hourOfDay dadFlexCenter _6h" style="height:${TABLE_ROW_HEIGHT_PX}"><span>6</span></div>
            <div class="hourOfDay dadFlexCenter _7h" style="height:${TABLE_ROW_HEIGHT_PX}"><span>7</span></div>
            <div class="hourOfDay dadFlexCenter _8h" style="height:${TABLE_ROW_HEIGHT_PX}"><span>8</span></div>
            <div class="hourOfDay dadFlexCenter _9h" style="height:${TABLE_ROW_HEIGHT_PX}"><span>9</span></div>
            <div class="hourOfDay dadFlexCenter _10h" style="height:${TABLE_ROW_HEIGHT_PX}"><span>10</span></div>
            <div class="hourOfDay dadFlexCenter _11h" style="height:${TABLE_ROW_HEIGHT_PX}"><span>11</span></div>
            <div class="hourOfDay dadFlexCenter _12h" style="height:${TABLE_ROW_HEIGHT_PX}"><span>12</span></div>
            <div class="hourOfDay dadFlexCenter _13h" style="height:${TABLE_ROW_HEIGHT_PX}"><span>13</span></div>
            <div class="hourOfDay dadFlexCenter _14h" style="height:${TABLE_ROW_HEIGHT_PX}"><span>14</span></div>
            <div class="hourOfDay dadFlexCenter _15h" style="height:${TABLE_ROW_HEIGHT_PX}"><span>15</span></div>
            <div class="hourOfDay dadFlexCenter _16h" style="height:${TABLE_ROW_HEIGHT_PX}"><span>16</span></div>
            <div class="hourOfDay dadFlexCenter _17h" style="height:${TABLE_ROW_HEIGHT_PX}"><span>17</span></div>
            <div class="hourOfDay dadFlexCenter _18h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"><span>18</span></div>
            <div class="hourOfDay dadFlexCenter _19h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"><span>19</span></div>
            <div class="hourOfDay dadFlexCenter _20h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"><span>20</span></div>
            <div class="hourOfDay dadFlexCenter _21h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"><span>21</span></div>
            <div class="hourOfDay dadFlexCenter _22h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"><span>22</span></div>
            <div class="hourOfDay dadFlexCenter _23h notWorkTime endDayHour" style="height:${TABLE_ROW_HEIGHT_PX}"><span>23</span></div>
        `;
        return column;
    }
    function createColumn(dayWeekNumber) {
        let column = document.createElement("div");
        let classList = column.classList;
        let dayName = "";
        classList.add("column", "positionRelative", "dayOfWeek", `_${dayWeekNumber}`);

        switch (dayWeekNumber) {
            case 1:
                classList.add("mon");
                dayName = "Mon";
                break;
            case 2:
                classList.add("tue");
                dayName = "Tue";
                break;
            case 3:
                classList.add("wed");
                dayName = "Wed";
                break;
            case 4:
                classList.add("thu");
                dayName = "Thu";
                break;
            case 5:
                classList.add("fri");
                dayName = "Fri";
                break;
            case 6:
                classList.add("sat", "weekend");
                dayName = "Sat";
                break;
            case 0:
                classList.add("sun", "weekend");
                dayName = "Sun";
                break;
        }

        const innerHTML = `
            <div class="columName dadFlexCenter" style="height:${TABLE_ROW_HEIGHT_PX}"><span>${dayName}</span></div>
            <div class="hourOfDay _0h notWorkTime startDayHour" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _1h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _2h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _3h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _4h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _5h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _6h" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _7h" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _8h" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _9h" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _10h" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _11h" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _12h" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _13h" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _14h" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _15h" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _16h" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _17h" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _18h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _19h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _20h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _21h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _22h notWorkTime" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
            <div class="hourOfDay _23h notWorkTime endDayHour" style="height:${TABLE_ROW_HEIGHT_PX}"></div>
        `;
        column.innerHTML = innerHTML;

        return column;
    }

    renderTableTag.appendChild(createFirstColumn());
    //EXPLAIN: thứ 2 -> thứ 7
    for (let i = 1; i <= 6; i++) renderTableTag.appendChild(createColumn(i));
    //EXPLAIN: chủ nhật, do chủ nhật là số 0, thứ 2 là 1, ...
    renderTableTag.appendChild(createColumn(0));

    dayweekElements = Array.from(renderTableTag.querySelectorAll(".dayOfWeek"));
}
function classTimeFormat(hour = 0, minute = 0) {
    return (hour < 10 ? "0" + hour : hour) + ':' + (minute < 10 ? "0" + minute : minute)
}
function appendRenderClassDiv(classs) {
    let thu = classs["thu"];
    let time = classs["thoiGian"];

    let color = { R: 255 - Math.random() * 150, G: 255 - Math.random() * 150, B: 255 - Math.random() * 150 };

    //EXPLAIN: 1 + là do tính cả column name nên cần thêm vào;
    let top = (1 + time.startHour + time.startMinute / 60) * TABLE_ROW_HEIGHT;

    let height = (time.endHour - time.startHour + (time.endMinute - time.startMinute) / 60) * TABLE_ROW_HEIGHT;

    let thoiGianString = classTimeFormat(time.startHour, time.startMinute) + " - " + classTimeFormat(time.endHour, time.endMinute);

    let div = document.createElement("div");
    div.classList.add("classRender", "positionAbsolute");
    div.style.top = `${top}px`;
    div.style.height = `${height}px`;
    div.style.backgroundColor = `rgb(${color.R},${color.G},${color.B})`;
    div.innerHTML = `
        <div class="classContainer positionRelative dadFlexCenter">
            <div class="classProps">
                <div class="tenHocPhan classProp">${classs["tenHocPhan"]} (${classs["loaiLop"]})</div>
                <div class="thoiGian classProp">${thoiGianString}</div>
                <div class="phong classProp">${classs["phong"]}</div>
            </div>

            <div class="otherClassProps positionAbsolute">
                <span class="maLop classProp">Mã lớp: ${classs["maLop"]}</span>
                <br>
                <span class="maHocPhan classProp">Mã HP: ${classs["maHocPhan"]}</span>
                <div>
                    <!-- <span class="thu classProp">Thứ: ${thu}</span> -->
                    <span class="tuan classProp">Tuần: ${classs["tuan"]}</span>
                </div>
                <span class="ngay classProp">Ngày: ${classs["ngay"]}</span>
                <br>
                <span class="nhom classProp">Nhóm: ${classs["nhom"]}</span>
                <div>
                    <span class="ghiChu classProp">${classs["ghiChu"]}</span>
                </div>
            </div>
        </div>
    `;
    div.style.zIndex = 20 - thu;

    let props = div.querySelector(".classProps");
    let classProps = div.querySelector(".otherClassProps");

    props.addEventListener("mousedown", () => {
        classProps.classList.toggle("hidden");
    });

    classProps.classList.add("hidden");

    dayweekElements[thu - 2].appendChild(div);
    previewClassesDayWeek[thu - 2].push({
        ...classs,
        div: div
    });

}

//SECTION: helper method
function hasClassThisWeek(classWeek = "") {
    if (classWeek == null || classWeek == undefined || classWeek == "") return false;

    let subWeeks = classWeek.split(",");
    for (let i = 0; i < subWeeks.length; i++) {
        let week = subWeeks[i];
        let temp = week.split("-");
        switch (temp.length) {
            case 1:
                if (parseInt(week) == getWeekPreview_Value()) return true;
                break;
            case 2:
                let startWeek = parseInt(temp[0]);
                let endWeek = parseInt(temp[1]);
                for (let i = startWeek; i <= endWeek; i++) {
                    if (i == getWeekPreview_Value()) return true;
                };
                break;
            default:
                return true;
        }

    };

    return false;
}
function notHaveClassTime(classWeek = "") {
    return classWeek == "";
}
function hideOtherClassProps() {
    renderTableTag.querySelectorAll(".otherClassProps").forEach(e => e.style.display = "none");
}

//EXPLAIN: giữ mảng chính, clear mảng ngày, clear html div.class
function clearOnlyClassRenders() {
    previewClassesDayWeek = [[], [], [], [], [], [], []];
    dayweekElements.forEach(dayOfWeek => dayOfWeek.querySelectorAll(".classRender").forEach(each => each.remove()));
}
function clearNotificationQueue() {
    messageQueueTag.innerHTML = "";
}
function clearAllOtherClassProps() {
    Array.from(renderTableTag.querySelectorAll(".otherClassProps")).forEach(each => {
        each.classList.add("hidden");
    });
}

//SECTION: rendering
function renderStudyClass(classs) {
    let cacBuoiHoc = classs["cacBuoiHoc"];
    if (!cacBuoiHoc) return;
    for (const buoiHoc of cacBuoiHoc) {
        let tuanHoc = buoiHoc["tuanHoc"];
        if (notHaveClassTime(tuanHoc)) {
            addNotHaveTimeClass(classs);
            continue;
        } else if (!hasClassThisWeek(tuanHoc)) continue;

        let thuHoc = buoiHoc["thuHoc"];

        let thoiGianHoc = buoiHoc["thoiGianHoc"];//EXPLAIN: VD: 1234-5678 -> 12h34p - 56h78p
        let time = {
            startHour: parseInt(thoiGianHoc.substr(0, 2)),
            startMinute: parseInt(thoiGianHoc.substr(2, 3)),
            endHour: parseInt(thoiGianHoc.substr(5, 2)),
            endMinute: parseInt(thoiGianHoc.substr(7, 2))
        }

        let patternObject = {
            maLop: classs["maLop"],
            loaiLop: classs["loaiLop"],
            maHocPhan: classs["maHocPhan"],
            tenHocPhan: classs["tenHocPhan"],

            thoiGian: time,
            thu: thuHoc,
            phong: buoiHoc["phongHoc"],
            tuan: tuanHoc,

            nhom: null,
            ngay: null,
            ghiChu: classs["ghiChu"]
        }

        appendRenderClassDiv(patternObject);
    }
}
function renderMidExamClass(classs) {
    let cacNhom = classs["thiGiuaKi"];
    if (!cacNhom) return;
    for (const nhomThi of cacNhom) {
        let tuanThi = nhomThi["tuanThi"].substr(1);
        if (notHaveClassTime(tuanThi)) {
            addNotHaveTimeClass(classs);
            continue;
        } else if (!hasClassThisWeek(tuanThi)) continue;

        let thuThi = nhomThi["thuThi"];
        if (thuThi == null || thuThi == undefined || thuThi == "") continue;
        switch (thuThi) {
            case "Thứ hai": thuThi = 2; break;
            case "Thứ ba": thuThi = 3; break;
            case "Thứ tư": thuThi = 4; break;
            case "Thứ năm": thuThi = 5; break;
            case "Thứ sáu": thuThi = 6; break;
            case "Thứ bảy": thuThi = 7; break;
            case "Chủ nhật": thuThi = 8; break;
        }

        let kipThi = nhomThi["kipThi"];//EXPLAIN: VD: 1234-5678 -> 12h34p - 56h78p
        let time = {
            startHour: 0,
            startMinute: 0,
            endHour: 0,
            endMinute: 0
        }

        if (kipThi.match(/Kíp \d-\d/ig)) {
            let intStart = kipThi.charAt(4);
            let intEnd = kipThi.charAt(6);
            switch (intStart) {
                case "1": time.startHour = 7; time.startMinute = 0; break;
                case "2": time.startHour = 9; time.startMinute = 30; break;
                case "3": time.startHour = 12; time.startMinute = 30; break;
                case "4": time.startHour = 15; time.startMinute = 0; break;
            }
            switch (intEnd) {
                case "1": time.endHour = 8; time.endMinute = 30; break;
                case "2": time.endHour = 11; time.endMinute = 0; break;
                case "3": time.endHour = 14; time.endMinute = 0; break;
                case "4": time.endHour = 16; time.endMinute = 30; break;
            }
        } else if (kipThi.match(/Kíp 1/ig)) {
            time.startHour = 7;
            time.startMinute = 0;
            time.endHour = 8;
            time.endMinute = 30;
        } else if (kipThi.match(/Kíp 2/ig)) {
            time.startHour = 9;
            time.startMinute = 30;
            time.endHour = 11;
            time.endMinute = 0;
        } else if (kipThi.match(/Kíp 3/ig)) {
            time.startHour = 12;
            time.startMinute = 30;
            time.endHour = 14;
            time.endMinute = 0;
        } else if (kipThi.match(/Kíp 4/ig)) {
            time.startHour = 15;
            time.startMinute = 0;
            time.endHour = 16;
            time.endMinute = 30;
        } else {
            let matches = kipThi.match(/\d+h\d*/ig);
            // console.log(matches);
            if (matches) {
                let temp = matches[0].split("h");
                time.startHour = parseInt(temp[0]);
                time.startMinute = parseInt(temp[1] == "" ? "0" : temp[1]);
                if (matches[1] == undefined) {
                    time.endHour = time.startHour + 1;
                    time.startMinute = time.startMinute;
                } else {
                    temp = matches[1].split("h");
                    time.endHour = parseInt(temp[0]);
                    time.endMinute = parseInt(temp[1] == "" ? "0" : temp[1]);
                }

            }
        }

        let patternObject = {
            maLop: classs["maLop"],
            loaiLop: classs["loaiLop"],
            maHocPhan: classs["maHocPhan"],
            tenHocPhan: classs["tenHocPhan"],

            thoiGian: time,
            thu: thuThi,
            phong: nhomThi["phongThi"],
            tuan: tuanThi,

            nhom: nhomThi["name"],
            ngay: nhomThi["ngayThi"],
            ghiChu: classs["ghiChu"]
        }

        appendRenderClassDiv(patternObject);
    }
}
function renderEndExamClass(classs) {
    let cacNhom = classs["thiCuoiKi"];
    if (!cacNhom) return;
    for (const nhomThi of cacNhom) {
        let tuanThi = nhomThi["tuanThi"].substr(1);
        if (notHaveClassTime(tuanThi)) {
            addNotHaveTimeClass(classs);
            continue;
        } else if (!hasClassThisWeek(tuanThi)) continue;

        let thuThi = nhomThi["thuThi"];
        if (thuThi == null || thuThi == undefined || thuThi == "") continue;
        switch (thuThi) {
            case "Thứ hai": thuThi = 2; break;
            case "Thứ ba": thuThi = 3; break;
            case "Thứ tư": thuThi = 4; break;
            case "Thứ năm": thuThi = 5; break;
            case "Thứ sáu": thuThi = 6; break;
            case "Thứ bảy": thuThi = 7; break;
            case "Chủ nhật": thuThi = 8; break;
        }

        let kipThi = nhomThi["kipThi"];//EXPLAIN: VD: 1234-5678 -> 12h34p - 56h78p
        let time = {
            startHour: 0,
            startMinute: 0,
            endHour: 0,
            endMinute: 0
        }
        if (kipThi.match(/Kíp \d-\d/ig)) {
            let intStart = kipThi.charAt(4);
            let intEnd = kipThi.charAt(6);
            switch (intStart) {
                case "1": time.startHour = 7; time.startMinute = 0; break;
                case "2": time.startHour = 9; time.startMinute = 30; break;
                case "3": time.startHour = 12; time.startMinute = 30; break;
                case "4": time.startHour = 15; time.startMinute = 0; break;
            }
            switch (intEnd) {
                case "1": time.endHour = 8; time.endMinute = 30; break;
                case "2": time.endHour = 11; time.endMinute = 0; break;
                case "3": time.endHour = 14; time.endMinute = 0; break;
                case "4": time.endHour = 16; time.endMinute = 30; break;
            }
        } else if (kipThi.match(/Kíp 1/ig)) {
            time.startHour = 7;
            time.startMinute = 0;
            time.endHour = 8;
            time.endMinute = 30;
        } else if (kipThi.match(/Kíp 2/ig)) {
            time.startHour = 9;
            time.startMinute = 30;
            time.endHour = 11;
            time.endMinute = 0;
        } else if (kipThi.match(/Kíp 3/ig)) {
            time.startHour = 12;
            time.startMinute = 30;
            time.endHour = 14;
            time.endMinute = 0;
        } else if (kipThi.match(/Kíp 4/ig)) {
            time.startHour = 15;
            time.startMinute = 0;
            time.endHour = 16;
            time.endMinute = 30;
        }

        let patternObject = {
            maLop: classs["maLop"],
            loaiLop: classs["loaiLop"],
            maHocPhan: classs["maHocPhan"],
            tenHocPhan: classs["tenHocPhan"],

            thoiGian: time,
            thu: thuThi,
            phong: nhomThi["phongThi"],
            tuan: tuanThi,

            nhom: nhomThi["name"],
            ngay: nhomThi["ngayThi"],
            ghiChu: classs["ghiChu"]
        }

        appendRenderClassDiv(patternObject);
    }
}
function renderClasses(classes = []) {
    clearNotificationQueue();
    clearOnlyClassRenders();

    for (const classs of classes) {
        renderStudyClass(classs);
        renderMidExamClass(classs);
        renderEndExamClass(classs);
    }

    scanOverlapTimeClasses();
    updateNumberMessages();
}
function scanOverlapTimeClasses() {
    //EXPLAIN: iterate every dayweek
    for (const classes of previewClassesDayWeek) {
        let overlapHandeledClasses = [];//EXPLAIN: handled class on that day, skip when meet again

        //EXPLAIN: iterate classes on that day
        for (const mainClass of classes) {
            if (existInArray(mainClass, overlapHandeledClasses)) continue;

            let existOverlap = false;
            let overlapClasses = [];//EXPLAIN: array with all class that same with main
            // use after iterate all to alert to speical queue

            //EXPLAIN: main class compare with other class on that day
            // if overlap then existOverlap = true
            for (const otherClass of classes) {
                if (otherClass == mainClass) continue;

                let mainTime = mainClass["thoiGian"];
                let otherTime = otherClass["thoiGian"];

                let mainStart = mainTime.startHour * 60 + mainTime.startMinute;
                let otherStart = otherTime.startHour * 60 + otherTime.startMinute;

                let mainEnd = mainTime.endHour * 60 + mainTime.endMinute;
                let otherEnd = otherTime.endHour * 60 + otherTime.endMinute;

                let notOverlap = mainStart > otherEnd || mainEnd < otherStart;
                if (notOverlap) continue;

                existOverlap = true;
                overlapHandeledClasses.push(otherClass);
                overlapClasses.push(otherClass);
            }

            //EXPLAIN: if have overlap add mainClass to handled so skip if meet again
            if (existOverlap) {
                overlapHandeledClasses.push(mainClass);
                overlapClasses.push(mainClass);
                addOverlapTimeClasses(overlapClasses);
            }
        }
    }
}

//SECTION: change page messages
function updateNumberMessages() {
    var openPageMessages = document.getElementById("openPageMessages");
    var numberMessagesTag = document.getElementById("numberOfMessages");

    let messages = messageQueueTag.querySelectorAll(".message");
    numberMessagesTag.innerHTML = `<span class="centerText">${messages.length}</span>`;

    if (messages.length == 0) {
        numberMessagesTag.style.display = "none";
        openPageMessages.classList.add("noMessage");
        openPageMessages.classList.remove("hasMessage");
    } else {
        numberMessagesTag.style.display = null;
        openPageMessages.classList.add("hasMessage");
        openPageMessages.classList.remove("noMessage");
    }
}
function addMessageToQueue(html = "", option = { event: "", listener: () => { } }) {
    let div = document.createElement("div");
    div.classList.add("message", "section");
    div.innerHTML = `${html}`;
    messageQueueTag.appendChild(div);
    if (option && option.event && option.listener) {
        div.addEventListener(option.event, option.listener);
    }
    updateNumberMessages();
}
function addNotHaveTimeClass(classs) {
    let html = `
        <h3 class="messageType">Special Case</h3>
        <div class="messageContent">
            <div class=""><b class="redText">ko thời gian</b></div>
            <div class="">${classs["tenHocPhan"]}</div>
            <div class="">${classs["ghiChu"]}</div>
        </div>
    `;
    addMessageToQueue(html);
}
function addOverlapTimeClasses(classes = []) {
    let html = classes.reduce((total, classs) => {

        let thoiGian = classs["thoiGian"];
        let startString = classTimeFormat(thoiGian.startHour, thoiGian.startMinute);
        let endString = classTimeFormat(thoiGian.endHour, thoiGian.endMinute);
        let thoiGianString = startString + "-" + endString;

        let innerHTML = `
            <div class="section">
                <div class="">${classs["tenHocPhan"]}</div>

                <div class=""><b class="redText">${thoiGianString}</b></div>
                <div class="">${classs["phong"]}</div>

                <div class=""><b class="redText">${classs["ngay"]}</b></div>
                <div class="">${classs["nhom"]}</div>
            </div>
        `;

        return total + innerHTML;
    }, "");
    html = `
        <h3 class="messageType">Special Case</h3>
        <div class="messageContent">
            <div class=""><b class="redText">trùng thời gian</b></div>
            <div class="dadFlexCenter">
                ${html}
            </div>
        </div>
    `;
    addMessageToQueue(html);
}


//SECTION: REALTIME ==========================================================================================================================
//CAUTION tính theo tây chủ nhật là 0 thứ 2 là 1,...
function calcCurrentWeek(firstWeekDay = "") {
    let start = dashToDate(firstWeekDay);
    let weeks = Math.floor(daysBetween(start, new Date()) / 7);
    return weeks + 1;//EXPLAIN: vd chia đc 0.5 thì là tuần 1, chia đc 1.2 là tuần 2 
}
function updateCurrentWeek(term = "") {
    let firstWeekDay = getWebApp_Term_FirstWeekDay(term);
    let result = calcCurrentWeek(firstWeekDay);
    setWebApp_localStorage("current-week", result);

    checkRealTime();
    return result;
}
function renderRealtimeDayWeek(tableElement, dayWeek) {
    tableElement.querySelectorAll(`._${dayWeek}`).forEach(each => each.classList.add("currentDayWeek"));
}
function clearRealtimeDayWeek(tableElement) {
    tableElement.querySelectorAll(".currentDayWeek").forEach(each => each.classList.remove("currentDayWeek"));
}

//SECTION: execute
function checkRealTime() {
    if (getWeekPreview_Value() == getWebApp_CurrentWeek()) {
        returnWeekButton.style.display = "none";
        startRealtimeRender();
    } else {
        returnWeekButton.style.display = null;
        stopRealtimeRender();
    }
}
function startRealtimeRender() {
    const realTimeRulerDiv = document.getElementById("renderRuler");
    renderRealtimeDayWeek(renderTableTag, new Date().getDay());
    realTimeRulerDiv.style.display = null;
}
function stopRealtimeRender() {
    const realTimeRulerDiv = document.getElementById("renderRuler");
    clearRealtimeDayWeek(renderTableTag);
    realTimeRulerDiv.style.display = "none";
}

(function () {
    let now = new Date();
    const NOW = { dayweek: now.getDay(), hour: now.getHours(), minute: now.getMinutes() };
    const HALF_RULER_HEIGHT = 1;
    const realTimeRulerDiv = document.getElementById("renderRuler");

    function updateRuler(element, option = { dayWeek: 0, hour: 0, minute: 0 }) {
        //EXPLAIN: 1 + là do tính cả column name nên cần thêm vào;
        let topPx = (1 + option.minute / 60 + option.hour) * TABLE_ROW_HEIGHT - HALF_RULER_HEIGHT;
        element.style.top = `${topPx}px`;
    }
    renderTableTag.addEventListener("click", function (e) {
        if (e.target.classList.contains("hourOfDay")) {
            clearAllOtherClassProps();
        }
    });
    window.addEventListener("resize", function (e) {
        // console.log(window.innerHeight, window.innerWidth);
    });

    setInterval(() => {
        let now = new Date();
        let minute = now.getMinutes();

        if (minute != NOW.minute) {
            NOW.minute = minute;
            let hour = now.getHours();

            if (hour != NOW.hour) {
                NOW.hour = hour;
                let dayweek = now.getDay();

                if (dayweek != NOW.dayweek) {
                    NOW.dayweek = dayweek;
                    clearRealtimeDayWeek(renderTableTag);
                    renderRealtimeDayWeek(renderTableTag, NOW.dayweek);

                    updateCurrentWeek(getTermPreview_Value());
                }
            }
        }

        updateRuler(realTimeRulerDiv, NOW);
    }, 1000);
})()

