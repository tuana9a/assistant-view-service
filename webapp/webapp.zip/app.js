
const PREFIX_PWA = 'webapp';
const CACHE_NAME = 'webapp';
const URL_TO_CACHE = [
    '/',
    '/app.css',
    '/app.js',
    '/automate-register.html',
    '/favicon.ico',
    '/index.html',
    '/manifest.json',
    '/register-preview.html',
    // '/service-worker.js',
    // '/version.txt',
    '/common/animation.css',
    '/common/animation.js',
    '/common/button.css',
    '/common/common.css',
    '/common/common.js',
    '/common/dad-child.css',
    '/common/form.css',
    '/common/sign.css',
    '/common/size.css',
    '/icons/manifest-icon-192.png',
    '/icons/manifest-icon-512.png',
    '/register-preview/query.js',
    '/register-preview/register-preview.css',
    '/register-preview/register-preview.js',
    '/register-preview/timetable.css',
    '/register-preview/timetable.js'
];

if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
        navigator.serviceWorker.register('/service-worker.js').then(function (e) {
            console.log('Service Worker registered');
        }).catch(function (e) {
            console.log('Service Worker register failed');
        });
    });
}

async function clearWebApp_Caches() {
    return caches.keys().then(function (cacheNames) {
        return Promise.all(cacheNames.map(function (cacheName) {
            return caches.delete(cacheName);
        }));
    });
}

async function updateWebApp_Caches() {
    await clearWebApp_Caches();
    await caches.open(CACHE_NAME).then(function (cache) {
        return cache.addAll(URL_TO_CACHE.map(function (url) {
            return new Request(url, { cache: "reload" });
        }));
    });
}

async function unregisterServiceWorkers() {
    return navigator.serviceWorker.getRegistrations().then(function (serviceWorkers) {
        return serviceWorkers.map(function (serviceWorker) {
            return serviceWorker.unregister();
        });
    });
}

function notification(title = "", options = { body: "", data: {}, actions: [{ action: "", title: "" }] }) {
    if (Notification.permission == 'granted') {
        navigator.serviceWorker.getRegistration().then(function (serviceWorker) {
            serviceWorker.showNotification(title, {
                ...options,
                icon: 'icons/manifest-icon-192.png',
                silent: true,
            });
        });
    }
}

(async function () {
    Notification.requestPermission(function (status) {
        console.log('Notification permission status:', status);
    });

    let versionTag = document.getElementById("version");
    let clientVersion = getLocalStorage(PREFIX_PWA, "version");
    let newestVersion = clientVersion;
    versionTag.innerText = "v" + (clientVersion || "0.0.0");

    let buttonUpdate = document.getElementById("update");
    let updatingSign = document.getElementById("updating");
    let updateSuccessSign = document.getElementById("update-success");
    let updateErrorSign = document.getElementById("update-error");

    function updateSuccess() {
        updatingSign.style.display = "none";
        updateSuccessSign.style.display = null;

        versionTag.innerText = "v" + (newestVersion || "0.0.0");
        setLocalStorage(PREFIX_PWA, "version", newestVersion);
    }
    function updateError() {
        updatingSign.style.display = "none";
        updateErrorSign.style.display = null;
    }

    buttonUpdate.addEventListener("click", function () {
        updatingSign.style.display = null;
        updateErrorSign.style.display = "none";
        updateSuccessSign.style.display = "none";

        updateWebApp_Caches()
            .then(updateSuccess)
            .catch(updateError);
    });

    ajax({ url: "/version.txt", method: "GET" }, (data) => {
        newestVersion = data;
        if (clientVersion != newestVersion) {
            notification("Update Available", {
                body: `New version ${newestVersion} is ready, You can go to home page and update whenever you want`,
                actions: [
                    { action: "ok", title: "Ok <3" },
                    { action: "close", title: "Close" },
                ],
            });
        }
    });
})()
