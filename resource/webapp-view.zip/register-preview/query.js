//SECTION: REQUEST =================================================================================================================
async function query_Terms_Json(callback = console.log) {
    return ajax({ url: '/terms.json', method: 'GET' }, callback);
}
async function query_GuessClasses(value = '', term = '', callback = console.log) {
    let query = generateQueryFromClassIds(extractClassIdsFromString(value));
    let url = `/api/public/register-preview/classes?ids=${query}&term=${term}&type=near`;
    return ajax({ url: url, method: 'GET' }, callback);
}
async function query_RegisterClasses(term = '', ids = [], callback = console.log) {
    let query = generateQueryFromClassIds(ids);
    let url = `/api/public/register-preview/classes?ids=${query}&term=${term}&type=match`;
    return ajax({ url: url, method: 'GET' }, callback);
}
async function query_StudentRegister(term = '', mssv = '', callback = console.log) {
    let url = `/api/public/register-preview/student?term=${term}&mssv=${mssv}`;
    return ajax({ url: url, method: 'GET' }, callback);
}
