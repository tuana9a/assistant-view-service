//SECTION: REQUEST =================================================================================================================
async function queryTerms_JsonCallback(callback = console.log) {
    return ajax({ url: '/terms.json', method: 'GET' }, callback);
}
async function queryGuessClassesCallback(value = '', term = '', callback = console.log) {
    let query = generateQueryFromClassIds(extractClassIdsFromString(value));
    let url = `/api/public/register-preview/classes?ids=${query}&term=${term}&type=near`;
    return ajax({ url: url, method: 'GET' }, callback);
}
async function queryRegisterClassesCallback(term = '', ids = [], callback = console.log) {
    let query = generateQueryFromClassIds(ids);
    let url = `/api/public/register-preview/classes?ids=${query}&term=${term}&type=match`;
    return ajax({ url: url, method: 'GET' }, callback);
}
async function queryStudentRegisterCallback(term = '', mssv = '', callback = console.log) {
    let url = `/api/public/register-preview/student?term=${term}&mssv=${mssv}`;
    return ajax({ url: url, method: 'GET' }, callback);
}
