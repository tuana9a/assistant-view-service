// var TABLE_ROW_HEIGHT = 23;
var TABLE_ROW_HEIGHT = 25;
var TABLE_ROW_HEIGHT_PX = TABLE_ROW_HEIGHT + 'px';

const NUM_OF_HOUR = 24;
const NUM_OF_DAYWEEK = 7;
var previewClasses = []; //EXPLAIN: mảng lữu dữ liệu class hiện tại
var dayweekElements = []; //EXPLAIN: mảng lưu các div thứ trong tuần
var dayweekElements_HourOfDays = [[], [], [], [], [], [], []]; //EXPLAIN: mảng lưu hourOfDay
var dayweekClasses = [[], [], [], [], [], [], []]; //EXPLAIN: tiện cho render, check trùng thời gian

var renderTableTag = document.getElementById('renderTable');

function classTimeFormat(hour = 0, minute = 0) {
    return (hour < 10 ? '0' + hour : hour) + ':' + (minute < 10 ? '0' + minute : minute);
}

//SECTION: helper method
function hasClassThisWeek(classWeek = '') {
    if (classWeek == null || classWeek == undefined || classWeek == '') return false;

    let subWeeks = classWeek.split(',');
    for (let i = 0; i < subWeeks.length; i++) {
        let week = subWeeks[i];
        let temp = week.split('-');
        switch (temp.length) {
            case 1:
                if (parseInt(week) == getWeekPreview_Value()) return true;
                break;
            case 2:
                let startWeek = parseInt(temp[0]);
                let endWeek = parseInt(temp[1]);
                for (let i = startWeek; i <= endWeek; i++) {
                    if (i == getWeekPreview_Value()) return true;
                }
                break;
            default:
                return true;
        }
    }

    return false;
}
function notHaveClassTime(classWeek = '') {
    return classWeek == '';
}
function hideOtherClassProps() {
    renderTableTag.querySelectorAll('.otherClassProps').forEach((e) => (e.style.display = 'none'));
}
function getHourOfDayElement(thu, gio) {
    return dayweekElements_HourOfDays[thu - 2][gio];
}

//EXPLAIN: giữ mảng chính, clear mảng ngày, clear html div.class
function clearOnlyClassRenders() {
    dayweekClasses = dayweekClasses.map(() => []); //EXPLAIN: reset each day of week
    dayweekElements.forEach((dayOfWeek) => dayOfWeek.querySelectorAll('.classRender').forEach((each) => each.remove()));
}
function clearNotificationQueue() {
    var messageQueueTag = document.getElementById('messageQueue');
    messageQueueTag.innerHTML = '';
}
function clearAllOtherClassProps() {
    Array.from(renderTableTag.querySelectorAll('.otherClassProps')).forEach((each) => {
        each.classList.add('hidden');
    });
}

//SECTION: rendering
function table_create_Table(dropHours = new Set()) {
    renderTableTag.innerHTML = `
        <div class="renderRuler" id="renderRuler">
            <hr class="ruler">
        </div>
    `;

    function createHourIndexColumn(dropHours = new Set()) {
        let column = document.createElement('div');
        column.classList.add('column', 'indexHour');

        column.innerHTML = `<div class="columName" style="height:${TABLE_ROW_HEIGHT_PX}"><span></span></div>`;
        for (let i = 0; i < NUM_OF_HOUR; i++) {
            let hourOfDay = document.createElement('div');
            hourOfDay.classList.add('hourOfDay', `_${i}h`, 'dadFlexCenter');
            hourOfDay.style.height = TABLE_ROW_HEIGHT_PX;
            hourOfDay.innerHTML = `<span>${i}</span>`;
            if (dropHours.has(i)) hourOfDay.style.display = 'none';
            column.appendChild(hourOfDay);
        }

        return column;
    }
    function createDayWeekColumn(dayweek, dropHours = new Set()) {
        let column = document.createElement('div');
        let classList = column.classList;
        let dayName = '';
        classList.add('column', 'positionRelative', 'dayOfWeek', `_${dayweek}`);

        switch (dayweek) {
            case 2:
                classList.add('mon');
                dayName = 'Mon';
                break;
            case 3:
                classList.add('tue');
                dayName = 'Tue';
                break;
            case 4:
                classList.add('wed');
                dayName = 'Wed';
                break;
            case 5:
                classList.add('thu');
                dayName = 'Thu';
                break;
            case 6:
                classList.add('fri');
                dayName = 'Fri';
                break;
            case 7:
                classList.add('sat', 'weekend');
                dayName = 'Sat';
                break;
            case 8:
                classList.add('sun', 'weekend');
                dayName = 'Sun';
                break;
        }
        column.innerHTML = `<div class="columName dadFlexCenter" style="height:${TABLE_ROW_HEIGHT_PX}"><span>${dayName}</span></div>`;
        for (let i = 0; i < NUM_OF_HOUR; i++) {
            let hourOfDay = document.createElement('div');
            hourOfDay.classList.add('hourOfDay', `_${i}h`);
            hourOfDay.style.height = TABLE_ROW_HEIGHT_PX;
            if (dropHours.has(i)) hourOfDay.style.display = 'none';
            column.appendChild(hourOfDay);
        }
        return column;
    }

    renderTableTag.appendChild(createHourIndexColumn(dropHours)); //EXPLAIN: cột chỉ số thời gian
    [2, 3, 4, 5, 6, 7, 8].forEach((day) => renderTableTag.appendChild(createDayWeekColumn(day, dropHours)));

    dayweekElements = Array.from(renderTableTag.querySelectorAll('.dayOfWeek'));
    for (let i = 0; i < NUM_OF_DAYWEEK; i++) {
        dayweekElements_HourOfDays[i] = Array.from(dayweekElements[i].querySelectorAll('.hourOfDay'));
    }
}
function table_create_Element(object) {
    let thu = object['thu'];
    let time = object['thoiGian'];

    let hourOfDayElement = getHourOfDayElement(thu, time.startHour);
    let top = hourOfDayElement.offsetTop + (time.startMinute / 60) * TABLE_ROW_HEIGHT;
    let height = (time.endHour - time.startHour + (time.endMinute - time.startMinute) / 60) * TABLE_ROW_HEIGHT;

    let time_start = classTimeFormat(time.startHour, time.startMinute);
    let time_end = classTimeFormat(time.endHour, time.endMinute);

    let div = document.createElement('div');
    div.classList.add('classRender', 'positionAbsolute');
    div.style.top = `${top}px`;
    div.style.height = `${height}px`;
    div.style.backgroundColor = `rgb(${255 - Math.random() * 150},${255 - Math.random() * 150},${255 - Math.random() * 150
        })`;
    div.innerHTML = `
        <div class="classContainer positionRelative dadFlexCenter">
            <div class="classProps">
                <div class="tenHocPhan classProp">${object['tenHocPhan']} (${object['loaiLop']})</div>
                <div class="thoiGian classProp">${time_start + ' - ' + time_end}</div>
                <div class="phong classProp">${object['phong']}</div>
            </div>

            <div class="otherClassProps positionAbsolute">
                <span class="maLop classProp">Mã lớp: ${object['maLop']}</span>
                <br>
                <span class="maHocPhan classProp">Mã HP: ${object['maHocPhan']}</span>
                <div>
                    <!-- <span class="thu classProp">Thứ: ${thu}</span> -->
                    <span class="tuan classProp">Tuần: ${object['tuan']}</span>
                </div>
                <span class="ngay classProp">Ngày: ${object['ngay']}</span>
                <br>
                <span class="nhom classProp">Nhóm: ${object['nhom']}</span>
                <div>
                    <span class="ghiChu classProp">${object['ghiChu']}</span>
                </div>
            </div>
        </div>
    `;
    div.style.zIndex = 20 - thu;

    let props = div.querySelector('.classProps');
    let classProps = div.querySelector('.otherClassProps');

    props.addEventListener('mousedown', () => {
        classProps.classList.toggle('hidden');
    });

    classProps.classList.add('hidden');

    dayweekElements[thu - 2].appendChild(div);
    dayweekClasses[thu - 2].push({
        ...object,
        div: div
    });
}
function table_create_CacBuoiHoc_BuoiHoc(classs) {
    let cacBuoiHoc = classs['cacBuoiHoc'];
    if (!cacBuoiHoc) return;
    for (const buoiHoc of cacBuoiHoc) {
        let tuanHoc = buoiHoc['tuanHoc'];
        if (notHaveClassTime(tuanHoc)) {
            addNotHaveTimeClass(classs);
            continue;
        } else if (!hasClassThisWeek(tuanHoc)) continue;

        let thuHoc = buoiHoc['thuHoc'];

        let thoiGianHoc = buoiHoc['thoiGianHoc']; //EXPLAIN: VD: 1234-5678 -> 12h34p - 56h78p
        let time = {
            startHour: parseInt(thoiGianHoc.substr(0, 2)),
            startMinute: parseInt(thoiGianHoc.substr(2, 3)),
            endHour: parseInt(thoiGianHoc.substr(5, 2)),
            endMinute: parseInt(thoiGianHoc.substr(7, 2))
        };

        let patternObject = {
            maLop: classs['maLop'],
            loaiLop: classs['loaiLop'],
            maHocPhan: classs['maHocPhan'],
            tenHocPhan: classs['tenHocPhan'],

            thoiGian: time,
            thu: thuHoc,
            phong: buoiHoc['phongHoc'],
            tuan: tuanHoc,

            nhom: null,
            ngay: null,
            ghiChu: classs['ghiChu']
        };

        table_create_Element(patternObject);
    }
}
function table_create_ThiGiuaKi_NhomThi(classs, firstWeekDay = '') {
    let cacNhom = classs['thiGiuaKi'];
    if (!cacNhom) return;
    for (const nhomThi of cacNhom) {
        let tuanThi = nhomThi['tuanThi'].substr(1);
        if (tuanThi == '') {
            tuanThi = String(weeksFromStartDay(nhomThi['ngayThi'], firstWeekDay));
        }
        if (notHaveClassTime(tuanThi)) {
            addNotHaveTimeClass(classs);
            continue;
        } else if (!hasClassThisWeek(tuanThi)) continue;

        let thuThi = nhomThi['thuThi'];
        if (thuThi == null || thuThi == undefined || thuThi == '') continue;
        switch (thuThi) {
            case 'Thứ hai':
                thuThi = 2;
                break;
            case 'Thứ ba':
                thuThi = 3;
                break;
            case 'Thứ tư':
                thuThi = 4;
                break;
            case 'Thứ năm':
                thuThi = 5;
                break;
            case 'Thứ sáu':
                thuThi = 6;
                break;
            case 'Thứ bảy':
                thuThi = 7;
                break;
            case 'Chủ nhật':
                thuThi = 8;
                break;
        }

        let kipThi = nhomThi['kipThi']; //EXPLAIN: VD: 1234-5678 -> 12h34p - 56h78p
        let time = {
            startHour: 0,
            startMinute: 0,
            endHour: 0,
            endMinute: 0
        };

        if (kipThi.match(/Kíp \d-\d/gi)) {
            let intStart = kipThi.charAt(4);
            let intEnd = kipThi.charAt(6);
            switch (intStart) {
                case '1':
                    time.startHour = 7;
                    time.startMinute = 0;
                    break;
                case '2':
                    time.startHour = 9;
                    time.startMinute = 30;
                    break;
                case '3':
                    time.startHour = 12;
                    time.startMinute = 30;
                    break;
                case '4':
                    time.startHour = 15;
                    time.startMinute = 0;
                    break;
            }
            switch (intEnd) {
                case '1':
                    time.endHour = 8;
                    time.endMinute = 30;
                    break;
                case '2':
                    time.endHour = 11;
                    time.endMinute = 0;
                    break;
                case '3':
                    time.endHour = 14;
                    time.endMinute = 0;
                    break;
                case '4':
                    time.endHour = 16;
                    time.endMinute = 30;
                    break;
            }
        } else if (kipThi.match(/Kíp 1/gi)) {
            time.startHour = 7;
            time.startMinute = 0;
            time.endHour = 8;
            time.endMinute = 30;
        } else if (kipThi.match(/Kíp 2/gi)) {
            time.startHour = 9;
            time.startMinute = 30;
            time.endHour = 11;
            time.endMinute = 0;
        } else if (kipThi.match(/Kíp 3/gi)) {
            time.startHour = 12;
            time.startMinute = 30;
            time.endHour = 14;
            time.endMinute = 0;
        } else if (kipThi.match(/Kíp 4/gi)) {
            time.startHour = 15;
            time.startMinute = 0;
            time.endHour = 16;
            time.endMinute = 30;
        } else {
            let matches = kipThi.match(/\d+h\d*/gi);
            // console.log(matches);
            if (matches) {
                let temp = matches[0].split('h');
                time.startHour = parseInt(temp[0]);
                time.startMinute = parseInt(temp[1] == '' ? '0' : temp[1]);
                if (matches[1] == undefined) {
                    time.endHour = time.startHour + 1;
                    time.startMinute = time.startMinute;
                } else {
                    temp = matches[1].split('h');
                    time.endHour = parseInt(temp[0]);
                    time.endMinute = parseInt(temp[1] == '' ? '0' : temp[1]);
                }
            }
        }

        let patternObject = {
            maLop: classs['maLop'],
            loaiLop: classs['loaiLop'],
            maHocPhan: classs['maHocPhan'],
            tenHocPhan: classs['tenHocPhan'],

            thoiGian: time,
            thu: thuThi,
            phong: nhomThi['phongThi'],
            tuan: tuanThi,

            nhom: nhomThi['name'],
            ngay: nhomThi['ngayThi'],
            ghiChu: classs['ghiChu']
        };

        table_create_Element(patternObject);
    }
}
function table_create_ThiCuoiKi_NhomThi(classs, firstWeekDay = '') {
    let cacNhom = classs['thiCuoiKi'];
    if (!cacNhom) return;
    for (const nhomThi of cacNhom) {
        let tuanThi = nhomThi['tuanThi'].substr(1);
        if (tuanThi == '') {
            tuanThi = String(weeksFromStartDay(nhomThi['ngayThi'], firstWeekDay));
        }
        if (notHaveClassTime(tuanThi)) {
            addNotHaveTimeClass(classs);
            continue;
        } else if (!hasClassThisWeek(tuanThi)) continue;

        let thuThi = nhomThi['thuThi'];
        if (thuThi == null || thuThi == undefined || thuThi == '') continue;
        switch (thuThi) {
            case 'Thứ hai':
                thuThi = 2;
                break;
            case 'Thứ ba':
                thuThi = 3;
                break;
            case 'Thứ tư':
                thuThi = 4;
                break;
            case 'Thứ năm':
                thuThi = 5;
                break;
            case 'Thứ sáu':
                thuThi = 6;
                break;
            case 'Thứ bảy':
                thuThi = 7;
                break;
            case 'Chủ nhật':
                thuThi = 8;
                break;
        }

        let kipThi = nhomThi['kipThi']; //EXPLAIN: VD: 1234-5678 -> 12h34p - 56h78p
        let time = {
            startHour: 0,
            startMinute: 0,
            endHour: 0,
            endMinute: 0
        };
        if (kipThi.match(/Kíp \d-\d/gi)) {
            let intStart = kipThi.charAt(4);
            let intEnd = kipThi.charAt(6);
            switch (intStart) {
                case '1':
                    time.startHour = 7;
                    time.startMinute = 0;
                    break;
                case '2':
                    time.startHour = 9;
                    time.startMinute = 30;
                    break;
                case '3':
                    time.startHour = 12;
                    time.startMinute = 30;
                    break;
                case '4':
                    time.startHour = 15;
                    time.startMinute = 0;
                    break;
            }
            switch (intEnd) {
                case '1':
                    time.endHour = 8;
                    time.endMinute = 30;
                    break;
                case '2':
                    time.endHour = 11;
                    time.endMinute = 0;
                    break;
                case '3':
                    time.endHour = 14;
                    time.endMinute = 0;
                    break;
                case '4':
                    time.endHour = 16;
                    time.endMinute = 30;
                    break;
            }
        } else if (kipThi.match(/Kíp 1/gi)) {
            time.startHour = 7;
            time.startMinute = 0;
            time.endHour = 8;
            time.endMinute = 30;
        } else if (kipThi.match(/Kíp 2/gi)) {
            time.startHour = 9;
            time.startMinute = 30;
            time.endHour = 11;
            time.endMinute = 0;
        } else if (kipThi.match(/Kíp 3/gi)) {
            time.startHour = 12;
            time.startMinute = 30;
            time.endHour = 14;
            time.endMinute = 0;
        } else if (kipThi.match(/Kíp 4/gi)) {
            time.startHour = 15;
            time.startMinute = 0;
            time.endHour = 16;
            time.endMinute = 30;
        }

        let patternObject = {
            maLop: classs['maLop'],
            loaiLop: classs['loaiLop'],
            maHocPhan: classs['maHocPhan'],
            tenHocPhan: classs['tenHocPhan'],

            thoiGian: time,
            thu: thuThi,
            phong: nhomThi['phongThi'],
            tuan: tuanThi,

            nhom: nhomThi['name'],
            ngay: nhomThi['ngayThi'],
            ghiChu: classs['ghiChu']
        };

        table_create_Element(patternObject);
    }
}

function table_render_PreviewClasses(classes = [], term = '') {
    clearNotificationQueue();
    clearOnlyClassRenders();
    let firstWeekDay = getWebApp_Term_FirstWeekDay(term);

    for (const classs of classes) {
        table_create_CacBuoiHoc_BuoiHoc(classs);
        table_create_ThiGiuaKi_NhomThi(classs, firstWeekDay);
        table_create_ThiCuoiKi_NhomThi(classs, firstWeekDay);
    }

    scanOverlapTimeClasses();
    updateNumberMessages();
}
function scanOverlapTimeClasses() {
    //EXPLAIN: iterate every dayweek
    for (const classes of dayweekClasses) {
        let overlapHandeledClasses = []; //EXPLAIN: handled class on that day, skip when meet again

        //EXPLAIN: iterate classes on that day
        for (const mainClass of classes) {
            if (existInArray(mainClass, overlapHandeledClasses)) continue;

            let existOverlap = false;
            let overlapClasses = []; //EXPLAIN: array with all class that same with main
            // use after iterate all to alert to speical queue

            //EXPLAIN: main class compare with other class on that day
            // if overlap then existOverlap = true
            for (const otherClass of classes) {
                if (otherClass == mainClass) continue;

                let mainTime = mainClass['thoiGian'];
                let otherTime = otherClass['thoiGian'];

                let mainStart = mainTime.startHour * 60 + mainTime.startMinute;
                let otherStart = otherTime.startHour * 60 + otherTime.startMinute;

                let mainEnd = mainTime.endHour * 60 + mainTime.endMinute;
                let otherEnd = otherTime.endHour * 60 + otherTime.endMinute;

                let notOverlap = mainStart > otherEnd || mainEnd < otherStart;
                if (notOverlap) continue;

                existOverlap = true;
                overlapHandeledClasses.push(otherClass);
                overlapClasses.push(otherClass);
            }

            //EXPLAIN: if have overlap add mainClass to handled so skip if meet again
            if (existOverlap) {
                overlapHandeledClasses.push(mainClass);
                overlapClasses.push(mainClass);
                addOverlapTimeClasses(overlapClasses);
            }
        }
    }
}

//SECTION: change page messages
function updateNumberMessages() {
    var messageQueueTag = document.getElementById('messageQueue');

    var openPageMessages = document.getElementById('openPageMessages');
    var numberMessagesTag = document.getElementById('numberOfMessages');

    let messages = messageQueueTag.querySelectorAll('.message');
    numberMessagesTag.innerHTML = `<span class="centerText">${messages.length}</span>`;

    if (messages.length == 0) {
        numberMessagesTag.style.display = 'none';
        openPageMessages.classList.add('noMessage');
        openPageMessages.classList.remove('hasMessage');
    } else {
        numberMessagesTag.style.display = null;
        openPageMessages.classList.add('hasMessage');
        openPageMessages.classList.remove('noMessage');
    }
}
function addMessageToQueue(html = '', option = { event: '', listener: () => { } }) {
    var messageQueueTag = document.getElementById('messageQueue');

    let div = document.createElement('div');
    div.classList.add('message', 'section');
    div.innerHTML = `${html}`;
    messageQueueTag.appendChild(div);
    if (option && option.event && option.listener) {
        div.addEventListener(option.event, option.listener);
    }
    updateNumberMessages();
}
function addNotHaveTimeClass(classs) {
    let html = `
        <h3 class="messageType">Special Case</h3>
        <div class="messageContent">
            <div class=""><b class="redText">ko thời gian</b></div>
            <div class="">${classs['tenHocPhan']}</div>
            <div class="">${classs['ghiChu']}</div>
        </div>
    `;
    addMessageToQueue(html);
}
function addOverlapTimeClasses(classes = []) {
    let html = classes.reduce((total, classs) => {
        let thoiGian = classs['thoiGian'];
        let startString = classTimeFormat(thoiGian.startHour, thoiGian.startMinute);
        let endString = classTimeFormat(thoiGian.endHour, thoiGian.endMinute);
        let thoiGianString = startString + '-' + endString;

        let innerHTML = `
            <div class="section">
                <div class="">${classs['tenHocPhan']}</div>

                <div class=""><b class="redText">${thoiGianString}</b></div>
                <div class="">${classs['phong']}</div>

                <div class=""><b class="redText">${classs['ngay']}</b></div>
                <div class="">${classs['nhom']}</div>
            </div>
        `;

        return total + innerHTML;
    }, '');
    html = `
        <h3 class="messageType">Special Case</h3>
        <div class="messageContent">
            <div class=""><b class="redText">trùng thời gian</b></div>
            <div class="dadFlexCenter">
                ${html}
            </div>
        </div>
    `;
    addMessageToQueue(html);
}

//SECTION: REALTIME ==========================================================================================================================
//CAUTION tính theo tây chủ nhật là 0 thứ 2 là 1,...
function calcCurrentWeek(firstWeekDay = '') {
    let start = fromStringToDate_VN(firstWeekDay);
    let weeks = Math.floor(daysBetween(start, new Date()) / NUM_OF_DAYWEEK);
    return weeks + 1; //EXPLAIN: vd chia đc 0.5 thì là tuần 1, chia đc 1.2 là tuần 2
}
function updateCurrentWeek(term = '') {
    let firstWeekDay = getWebApp_Term_FirstWeekDay(term);
    let result = calcCurrentWeek(firstWeekDay);
    setWebApp_localStorage('current-week', result);

    checkRealtime();
    return result;
}
function checkRealtime() {
    if (getWeekPreview_Value() == getWebApp_CurrentWeek()) {
        returnWeekButton.style.display = 'none';
        realtime_show();
    } else {
        returnWeekButton.style.display = null;
        realtime_hide();
    }
}

function realtime_renderDayWeek(tableElement, dayWeek) {
    tableElement.querySelector(`.dayOfWeek._${dayWeek}`)?.classList.add('currentDayWeek');
}
function realtime_clearDayWeek(tableElement) {
    tableElement.querySelectorAll('.currentDayWeek').forEach((each) => each.classList.remove('currentDayWeek'));
}
function realtime_show() {
    const realTimeRulerDiv = document.getElementById('renderRuler');
    realtime_renderDayWeek(renderTableTag, toDayWeek_VN(new Date().getDay()));
    realTimeRulerDiv.style.display = null;
}
function realtime_hide() {
    const realTimeRulerDiv = document.getElementById('renderRuler');
    realtime_clearDayWeek(renderTableTag);
    realTimeRulerDiv.style.display = 'none';
}
function realtime_iterval(dropHours = new Set()) {
    let now = new Date();
    const CURRENT_NOW = { dayweek: now.getDay(), hour: now.getHours(), minute: now.getMinutes() };

    const rulerElement = renderTableTag.querySelector('#renderRuler');
    const HALF_RULER_HEIGHT = 1;

    setInterval(function () {
        now = new Date();
        CURRENT_NOW.minute = now.getMinutes();
        CURRENT_NOW.hour = now.getHours();

        //EXPLAIN: riêng ngày thì phải check để clear currentDay cũ
        if (now.getDay() != CURRENT_NOW.dayweek) {
            CURRENT_NOW.dayweek = now.getDay();
            realtime_clearDayWeek(renderTableTag);
            realtime_renderDayWeek(renderTableTag, toDayWeek_VN(CURRENT_NOW.dayweek));
            updateCurrentWeek(getTermPreview_Value()); //EXPLAIN: có thể đã chuyển tuần nên cần phải update
        }

        //SECTION: update ruler

        if (dropHours.has(CURRENT_NOW.hour)) return; //EXPLAIN: nếu out of range thì ngừng update
        let thu = toDayWeek_VN(CURRENT_NOW.dayweek);
        let hourOfDayElement = getHourOfDayElement(thu, CURRENT_NOW.hour);
        let top = hourOfDayElement.offsetTop + (CURRENT_NOW.minute / 60) * TABLE_ROW_HEIGHT - HALF_RULER_HEIGHT;

        rulerElement.style.top = `${top}px`;
    }, 1000);
}

//SECTION: main
(function () {
    let dropHours = new Set([]);
    table_create_Table(dropHours);
    realtime_iterval(dropHours);
})();
//SECTION: event listener
(function () {
    let renderContainer = renderTableTag.parentElement;
    renderContainer.style.height = 17 * TABLE_ROW_HEIGHT + "px";
    renderContainer.scrollTo(0, 5 * TABLE_ROW_HEIGHT);
    (function () {
        var deltaX = 0,
            deltaY = 0,
            positionX = 0,
            positionY = 0;
        renderContainer.addEventListener('mousedown', mousedown);

        //SECTION: mouse drag
        function mousedown(e) {
            e = e || window.event;
            // e.preventDefault();

            if (!e.target.classList.contains('hourOfDay')) return;
            // get the mouse cursor position at startup:
            positionX = e.clientX;
            positionY = e.clientY;

            document.addEventListener('mouseup', mouseup);
            document.addEventListener('mousemove', mousemove);
        }
        function mousemove(e) {
            e = e || window.event;
            e.preventDefault();
            // caculate delta from previos
            deltaX = e.clientX - positionX;
            deltaY = e.clientY - positionY;
            // calculate the new cursor position
            positionX = e.clientX;
            positionY = e.clientY;
            // set the element's new position
            renderContainer.scrollBy(-deltaX, -deltaY);
        }
        function mouseup(e) {
            // stop moving when mouse button is released:
            document.removeEventListener('mouseup', mouseup);
            document.removeEventListener('mousemove', mousemove);
        }
    })();

    renderTableTag.addEventListener('click', (e) => {
        if (e.target.classList.contains('hourOfDay')) clearAllOtherClassProps();
    });
})();
