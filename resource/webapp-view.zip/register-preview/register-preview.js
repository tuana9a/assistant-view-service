'use strict';

const PREFIX_PREVIEW = 'register-preview';

let inputClassIdTag = document.getElementById('inputClassId');
let inputMssvTag = document.getElementById('inputMssv');

let containerClassIdsTag = document.getElementById('classIds');
let containerGuessIdsTag = document.getElementById('guessIds');

let weekPreviewTag = document.getElementById('weekPreview');
let termPreviewTag = document.getElementById('termPreview');
let returnWeekButton = document.getElementById('returnCurrentWeek');

//SECTION: HELPER ===============================================================================================
function extractClassIdsFromString(value = '') {
    let result = value
        .split(/\s*,\s*|\s+/)
        .map((e) => e.replace(/[\D]+/g, ''))
        .filter((e) => e != '');
    return result;
}
function generateQueryFromClassIds(ids = []) {
    let result = ids
        .filter((e) => e != '')
        .reduce((total, each) => `${total}${each},`, '')
        .slice(0, -1);
    return result;
}
function reformatClasses(classes = []) {
    return classes.map((classs) => {
        delete classs._id;
        return classs;
    });
}

//SECTION: WEBAPP_DATA =====================================================================================
class WebApp_Preview {
    termPreview;
    weekPreview;
    userInputClassIds;
    classArray;
    constructor(termPreview = '20192', weekPreview = 0, userInputClassIds = [], classArray = []) {
        this.termPreview = termPreview;
        this.userInputClassIds = userInputClassIds;
        this.weekPreview = weekPreview;
        this.classArray = classArray;
    }
}

function setWebApp_localStorage(name = '', value) {
    setLocalStorage(PREFIX_PREVIEW, name, value);
}
function getWebApp_localStorage(name = '') {
    return getLocalStorage(PREFIX_PREVIEW, name);
}

//SECTION: classes thing
function setWebApp_Preview(data = new WebApp_Preview()) {
    setLocalStorage(PREFIX_PREVIEW, data.termPreview, data);
}
function getWebApp_Preview(term = '') {
    return getLocalStorage(PREFIX_PREVIEW, term);
}
function getWebApp_Term_FirstWeekDay(term = '') {
    let available = getWebApp_localStorage('terms');
    for (let key in available) {
        if (key == term) {
            return available[`${key}`].firstWeekDay;
        }
    }
    return dateToDash(new Date());
}

function fetchDataFromWebApp_Preview(term = '') {
    let previewData = getWebApp_Preview(term);
    if (!previewData) return;

    setWeekPreview_Value(previewData.weekPreview);
    previewData.userInputClassIds.forEach(addClassIdToContainer);

    previewClasses = previewData.classArray;
    table_render_PreviewClasses(previewClasses, term);
}
function startup_WebAppData() {
    let mssv = getWebApp_localStorage('mssv');
    if (mssv) setInputMssv_Value(mssv);

    let available = getWebApp_localStorage('terms');
    if (available) setTermPreview_Available(available);

    let currentTerm = getWebApp_localStorage('current-term');
    if (currentTerm) {
        updateCurrentWeek(currentTerm);
        setTermPreview_Value(currentTerm);
        fetchDataFromWebApp_Preview(currentTerm);
    }

    checkRealtime();
}

//SECTION: ALL CLASS ID, MSSV stuffs ==============================================================================================
function addClassIdToContainer(value) {
    function createClassIdDiv(value) {
        let div = document.createElement('div');
        div.classList.add('classId');
        div.innerHTML = `
            <span class="input" role="textbox" contenteditable>${value}</span>
            <span class="remove noSelect"><span>❌</span></span>
        `;
        div.querySelector('.remove').addEventListener('click', (e) => {
            div.remove();
        });
        return div;
    }
    containerClassIdsTag.appendChild(createClassIdDiv(value));
}
function addGuessIdToContainer(value) {
    function createClassIdDiv(value) {
        let div = document.createElement('div');
        div.classList.add('classId', 'noSelect');
        div.innerHTML = `<span class="maLop">${value}</span>`;
        div.addEventListener('click', (e) => {
            addClassIdToContainer(div.textContent);
            div.remove();
        });
        return div;
    }
    containerGuessIdsTag.appendChild(createClassIdDiv(value));
}

function clearContainerClassIds() {
    containerClassIdsTag.innerHTML = '';
}
function clearGuessIdsContainer() {
    containerGuessIdsTag.innerHTML = '';
}

function getInputClassIdValue() {
    return inputClassIdTag.value;
}
function clearInputClassIdValue() {
    inputClassIdTag.value = '';
}

function getInputMssv_Value() {
    return inputMssvTag.value;
}
function setInputMssv_Value(value = '') {
    inputMssvTag.value = value;
}

function getValueArrayFromUserInput() {
    let result = Array.from(containerClassIdsTag.querySelectorAll('.input')).map((e) => e.textContent.trim());
    return result;
}
function getClassIdsFromUserInput() {
    let result = [];
    getValueArrayFromUserInput().forEach((value) => {
        //EXPLAIN: vì 1 input có thể cho phép nhiều class (VD: 1235, 1234 - lớp LT, BT) ...
        let ids = extractClassIdsFromString(value);
        result.push(...ids);
    });
    return result;
}

function renderGuessIdsFromClasses(classes = []) {
    if (classes.length == 0) {
        containerGuessIdsTag.innerHTML = `<div><span style="color: var(--green_neon);">không tìm thấy</span></div>`;
        return;
    }
    classes.forEach((classs) => addGuessIdToContainer(`${classs.maLop} - ${classs.tenHocPhan} - ${classs.loaiLop}`));
}

//SECTION: WEEK, TERM =====================================================================================
function changeWeekPreview(delta = 0) {
    delta = parseInt(delta);
    let weekPreview = getWeekPreview_Value() + delta;
    let termPreview = getTermPreview_Value();

    setWeekPreview_Value(weekPreview);
    setWebApp_Preview(new WebApp_Preview(termPreview, weekPreview, getValueArrayFromUserInput(), previewClasses));

    table_render_PreviewClasses(previewClasses, termPreview);
    checkRealtime();
}
function getWebApp_CurrentWeek() {
    return getWebApp_localStorage('current-week') || 0;
}
function returnCurrentWeek() {
    setWeekPreview_Value(getWebApp_CurrentWeek());

    let termPreview = getTermPreview_Value();
    let weekPreview = getWeekPreview_Value(); //CAUTION: get week preview after set weekPreview
    table_render_PreviewClasses(previewClasses, termPreview);

    checkRealtime();
    setWebApp_Preview(new WebApp_Preview(termPreview, weekPreview, getValueArrayFromUserInput(), previewClasses));
}

function setWeekPreview_Value(value = -1) {
    value = parseInt(value);
    weekPreviewTag.textContent = value;
}
function getWeekPreview_Value() {
    let value = parseInt(weekPreviewTag.textContent);
    return value;
}

function switchTermPreviewHandler() {
    setTimeout(() => {
        clearOnlyClassRenders(); //EXPLAIN: nếu không thì render bị giữ khi chuyển term
        clearContainerClassIds(); //EXPLAIN: nếu không thì classIds sẽ giữ nguyên khi chuyển term

        let termPreview = getTermPreview_Value();
        updateCurrentWeek(termPreview); //EXPLAIN: current week after query terms
        fetchDataFromWebApp_Preview(termPreview);

        checkRealtime();
    }, 0);
}

function getTermPreview_Value() {
    return termPreviewTag.value;
}
function setTermPreview_Value(value = '') {
    termPreviewTag.value = value;
}
function setTermPreview_Available(available = {}) {
    let html = '';
    for (let term in available) {
        html += `<option value="${term}">${term}</option>`;
    }
    termPreviewTag.innerHTML = html;
}

//SECTION: BIG FUNCTION =====================================================================================
async function RENEW_SCHOOL_TERMS() {
    return Promise.all([
        query_Terms_Json((response) => {
            if (response) {
                let termPreview = getTermPreview_Value();
                let available = response.available;
                let current = response.current;

                setTermPreview_Available(available);

                setWebApp_localStorage('terms', available);
                setWebApp_localStorage('current-term', current);

                //CAUTION: current week after set webapp terms
                updateCurrentWeek(termPreview);
                setTermPreview_Value(termPreview);
            }
        })
    ]);
}
async function REGISTER_PREVIEW() {
    let loadingSign = document.getElementById('register-preview-loading-sign');

    loadingSign.style.display = null;
    let mssv = getInputMssv_Value();
    let studentRegister;
    let studentRegisterClasses = new Map();

    let termPreview = getTermPreview_Value();
    let weekPreview = getWeekPreview_Value();

    if (mssv != '') {
        let response = await query_StudentRegister(termPreview, mssv, (data) => data);
        if (response?.success) studentRegister = response.body;
        setWebApp_localStorage('mssv', mssv);
    }

    let classIds = getClassIdsFromUserInput();
    if (studentRegister) {
        classIds = studentRegister.dangKi.map((each) => {
            let maLop = each.maLop;
            studentRegisterClasses.set(maLop, each);
            return maLop;
        });
    }

    query_RegisterClasses(termPreview, classIds, (response) => {
        if (response?.success) {
            let classes = reformatClasses(response.body);

            if (studentRegister) {
                clearContainerClassIds();
                classes = classes.map((classs) => {
                    let nhom = studentRegisterClasses.get(classs.maLop).nhom;
                    classs.thiGiuaKi = classs.thiGiuaKi?.filter((each) => each.name == nhom);
                    classs.thiCuoiKi = classs.thiCuoiKi?.filter((each) => each.name == nhom);
                    addClassIdToContainer(`${classs.maLop} - ${classs.tenHocPhan} - ${classs.loaiLop}`);
                    return classs;
                });
            }

            //EXPLAIN: có thể change sau query với trường hợp dùng mssv
            let userInputClassIds = getValueArrayFromUserInput();

            //EXPLAIN: có thể query quá lâu người dùng chuyển kì sẽ bị sai
            if (getTermPreview_Value() == termPreview) {
                // nên check nếu đúng thì mới update giá trị và render
                previewClasses = classes;
                table_render_PreviewClasses(classes, termPreview);
            }

            setWebApp_Preview(new WebApp_Preview(termPreview, weekPreview, userInputClassIds, classes));
        }
        loadingSign.style.display = 'none';
    });
}

function executeOrder(number) {
    let autoRegisterTag = document.getElementById('auto-register');

    let inputPasswordTag = document.getElementById('inputPassword');
    let inputBeginTag = document.getElementById('inputBegin');

    switch (number) {
        case 66:
            autoRegisterTag.classList.toggle('hidden');
            break;

        case 69:
            autoRegisterTag.classList.add('hidden');

            let username = getInputMssv_Value();
            let password = inputPasswordTag.value;

            let beginDate = inputBeginTag.querySelector('#date').value;
            let beginTime = inputBeginTag.querySelector('#time').value;
            let begin = new Date(beginDate + ' ' + beginTime).getTime();

            let classIds = getClassIdsFromUserInput();
            let data = { username, password, classIds, begin, type: 'dk-sis' };
            data = JSON.stringify(data, null, '  ');
            let html = `
                <h3 class="messageType">Secret</h3>
                <div class="messageContent">
                    <div class=""><b class="redText">value</b></div>
                    <div class=""><span style="cursor: pointer; word-wrap: break-word;">${data}</span></div>
                </div>
            `;
            addMessageWithListener(html, {
                event: 'click',
                listener: function (e) {
                    this.remove();
                    navigator.clipboard.writeText(data).then(
                        function () {
                            console.log('Async: Copied to clipboard!');
                        },
                        function (err) {
                            console.error('Async: Could not copy: ', err);
                        }
                    );
                    updateNumberMessages();
                }
            });
            break;

        default:
            break;
    }
}

//SECTION: event listener;
(function () {
    let userInputTimeout;
    let pageMessagesContent = document.getElementById('pageMessagesContent');
    let openPageMessages = document.getElementById('openPageMessages');
    let closePageMessages = document.getElementById('closePageMessages');

    termPreviewTag.addEventListener('change', switchTermPreviewHandler);
    returnWeekButton.addEventListener('click', returnCurrentWeek);

    inputClassIdTag.addEventListener('keydown', (e) => {
        clearTimeout(userInputTimeout);
        userInputTimeout = setTimeout(async () => {
            let value = getInputClassIdValue();
            if (value == '') return;
            if (e.key == 'Enter') {
                addClassIdToContainer(value);
                clearInputClassIdValue();
            } else if (value.length > 4) {
                query_GuessClasses(value, getTermPreview_Value(), (response) => {
                    if (response?.success) {
                        clearGuessIdsContainer();
                        let classes = reformatClasses(response.body);
                        renderGuessIdsFromClasses(classes);
                    }
                });
            } else {
                clearGuessIdsContainer();
            }
        }, 50);
    });
    inputMssvTag.addEventListener('keydown', (e) => {
        if (e.key == 'Enter') {
            setTimeout(REGISTER_PREVIEW, 50);
        }
    });
    openPageMessages.addEventListener('click', () => {
        //EXPLAIN: check nếu đang dragging thì k kích hoạt
        if (openPageMessages.getAttribute('data-animation-dragging') == 'true') return;

        pageMessagesContent.classList.toggle('hidden');
        closePageMessages.classList.toggle('hidden');
    });
    closePageMessages.addEventListener('click', () => {
        pageMessagesContent.classList.add('hidden');
        closePageMessages.classList.add('hidden');
    });

    document.querySelectorAll('.REGISTER-PREVIEW').forEach((each) => {
        each.addEventListener('click', REGISTER_PREVIEW);
    });
    document.querySelectorAll('.toggleWeekPreview').forEach((each) => {
        let value = each.getAttribute('data-value');
        each.addEventListener('mousedown', () => {
            changeWeekPreview(value);
        });
    });
})();

//SECTION: main function
(async function () {
    startup_WebAppData();
    await RENEW_SCHOOL_TERMS();
    checkRealtime();
})();
