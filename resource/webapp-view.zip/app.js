const PREFIX_PWA = 'webapp';
const CACHE_NAME = 'webapp';
const ROOT_URL = '/';
const URL_NOT_CACHE = ['/terms.json', '/version.txt'];
const URL_CACHE = [
    ROOT_URL,
    '/app.css',
    '/app.js',
    '/favicon.ico',
    '/index.html',
    '/manifest.json',
    '/register-preview.html',
    '/service-worker.js',
    '/terms.json',
    '/version.txt',
    '/common/animation.css',
    '/common/animation.js',
    '/common/button.css',
    '/common/common.css',
    '/common/common.js',
    '/common/dad-child.css',
    '/fonts/Alata.ttf',
    '/icons/manifest-icon-192.png',
    '/icons/manifest-icon-512.png',
    '/register-preview/query.js',
    '/register-preview/register-preview.css',
    '/register-preview/register-preview.js',
    '/register-preview/timetable.css',
    '/register-preview/timetable.js'
].filter(function (url) {
    return !URL_NOT_CACHE.some(function (notCache) {
        return notCache == url;
    });
});

async function clearWebApp_Caches() {
    return caches.keys().then(function (cacheNames) {
        return Promise.all(
            cacheNames.map(function (cacheName) {
                return caches.delete(cacheName);
            })
        );
    });
}
async function backupWebApp_Caches() {
    let cache = await caches.open(CACHE_NAME);
    let backup = new Map();
    for (const url of URL_CACHE) {
        backup.set(url, await cache.match(new Request(url)));
    }
    return backup;
}
async function updateWebApp_Caches() {
    await clearWebApp_Caches();
    let cache = await caches.open(CACHE_NAME);
    return cache.addAll(
        URL_CACHE.map(function (url) {
            return new Request(url, { cache: 'reload' });
        })
    );
}

async function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function () {
            navigator.serviceWorker
                .register('/service-worker.js')
                .then(function (e) {
                    console.log('Service Worker: success');
                })
                .catch(function (e) {
                    console.log('Service Worker: FAILED');
                });
        });
    }
}
async function unregisterServiceWorkers() {
    return navigator.serviceWorker.getRegistrations().then(function (serviceWorkers) {
        return serviceWorkers.map(function (serviceWorker) {
            return serviceWorker.unregister();
        });
    });
}

function requestPermission_Notification() {
    Notification.requestPermission(function (status) {
        console.log('Notification Permission:', status);
    });
}
function notification(title = '', options = { body: '', data: {}, actions: [{ action: '', title: '' }] }) {
    if (Notification.permission == 'granted') {
        navigator.serviceWorker.getRegistration().then(function (serviceWorker) {
            serviceWorker.showNotification(title, {
                ...options,
                icon: 'icons/manifest-icon-192.png',
                silent: true
            });
        });
    }
}

(async function () {
    registerServiceWorker();
    console.log('Notification Permission:', Notification.permission);

    let versionTag = document.getElementById('version');
    let clientVersion = getLocalStorage(PREFIX_PWA, 'version');
    let newestVersion = clientVersion;
    versionTag.innerText = 'v' + (clientVersion || '0.0.0');

    let buttonUpdate = document.getElementById('updateButton');
    let updateAlert = buttonUpdate.querySelector('.alert');

    let LoadingSign = document.getElementById('updating');
    let SuccessSign = document.getElementById('update-success');
    let errorSign = document.getElementById('update-error');

    buttonUpdate.addEventListener('click', async function () {
        LoadingSign.style.display = null;
        errorSign.style.display = 'none';
        SuccessSign.style.display = 'none';

        let backup = await backupWebApp_Caches();
        updateWebApp_Caches()
            .then(function () {
                LoadingSign.style.display = 'none';
                SuccessSign.style.display = null;
                updateAlert.style.display = 'none';

                versionTag.innerText = 'v' + (newestVersion || '0.0.0');
                setLocalStorage(PREFIX_PWA, 'version', newestVersion);
            })
            .catch(function () {
                LoadingSign.style.display = 'none';
                errorSign.style.display = null;
                updateAlert.style.display = null;

                caches.open(CACHE_NAME).then(function (cache) {
                    for (const url of URL_CACHE) {
                        cache.put(new Request(url), backup.get(url));
                    }
                });
            });
    });

    ajax({ url: '/version.txt', method: 'GET' }, function (data) {
        newestVersion = data;
        if (clientVersion != newestVersion) {
            updateAlert.style.display = null;
            // notification('Update Available', {
            //     body: `New version ${newestVersion} is ready, You can go to home page and update whenever you want`,
            //     actions: [
            //         { action: 'ok', title: 'Ok <3' },
            //         { action: 'close', title: 'Close' }
            //     ]
            // });
        }
    });
})();
